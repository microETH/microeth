Blue Vinyl Fonts
(c)1997-2005 bluevinyl@bvfonts.com 
http://www.bvfonts.com

 The Freeware Font(s) included in this pack were created by Blue Vinyl Fonts, (aka Jess or bvfonts@bvfonts.com). I have been creating fonts since September 12,1997.I am inspired by my uncontrolable love for music and computer graphics (my only freinds).All fonts are original works from the mind of bluevinyl,wooooo scary. 
 Please do not include this font on any CD-Roms without written consent from bvfonts@bvfonts.com.  This font is not to be resold or remarketed.  This font is free to use in any private manner.  If you plan to use this font commercially in any manner please contact bvfonts@bvfonts.com concerning this for terms of commericial use.  
 This tt font zip file is not to be included on any other archive or personal website for download.Yes you may use this font to create graphics for your personal site just do not put the font file on the web site for download.

NO WARRANTIES. Blue Vinyl Fonts expressly disclaims any warranty for this SOFTWARE PRODUCT. This SOFTWARE PRODUCT and any related documentation is provided "as is" without warranty of any kind, either express or implied, including, without limitation, the implied warranties or merchantability, fitness for a particular purpose, or noninfringement. The entire risk arising out of use or performance of the SOFTWARE PRODUCT remains with you.

NO LIABILITY FOR CONSEQUENTIAL DAMAGES. In no event shall Blue Vinyl Fonts be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, loss of business information, or any other pecuniary loss) arising out of the use of or inability to use this product, even if Blue Vinyl Fonts has been advised of the possibility of such damages.

UNDER NO CIRCUMSTANCES SHOULD THESE FONTS BE USED IN A SIITAUTION THAT COULD ENDANGER LIFE OR THE ENVIROMENT. FOR INSTANCE AIRPLANE NAVIGATION, SAFETY SIGNS, etc. 

EDUCATIONAL PURPOSES: If this font is used in an educational situation it is up to you the user or teacher to confirm that they are useful and you take full responsibility for it's use.

Thank you ; )

All Rights Reserved by Blue Vinyl, 1997-2005.